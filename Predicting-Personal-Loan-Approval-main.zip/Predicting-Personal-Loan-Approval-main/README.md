# Predicting-Personal-Loan-Approval
video demonstration: https://drive.google.com/file/d/1wZZY6685RLcXoxrUpWZqKFyJAjtIeEAC/view?usp=share_link
